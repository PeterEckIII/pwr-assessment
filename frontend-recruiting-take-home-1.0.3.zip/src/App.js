import * as React from "react";

export default () => <div>Review Display</div>;
